from ZarTest02 import ZarTest02


class ZarTest02SL35(ZarTest02):
    stoploss = -0.35
